export const Icons = {
	google: "/assets/icons/google.png",
	Logo: "/assets/icon.jpeg",
};
