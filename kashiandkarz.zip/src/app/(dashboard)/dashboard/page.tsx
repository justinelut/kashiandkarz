
export const page = () => {
  return (
  <div></div>
  )
}

export default page
